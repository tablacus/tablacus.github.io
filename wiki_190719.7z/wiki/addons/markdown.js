if (marked) {
    MakeMarkDown();
} else {
    MainWindow.OpenHttpRequest("http://cdnjs.cloudflare.com/ajax/libs/marked/0.3.2/marked.min.js", "", SetMarkDown);
}

function SetMarkDown(xhr, url, arg1)
{
    new Function(xhr.get_responseText ? xhr.get_responseText() : xhr.responseText)();
}

function MakeMarkDown()
{
    var FV = GetFolderView();
    var src = api.PathSearchAndQualify(FV.FolderItem.Path + "\\..\\..\\..\\TablacusExplorerAddons.wiki");
    var wfd = api.Memory("WIN32_FIND_DATA");
	var hFind = api.FindFirstFile(fso.BuildPath(src, "*.md"), wfd);
    var bFind = hFind != INVALID_HANDLE_VALUE;
	while (bFind) {
		if (!/^\.\.?|^_/.test(wfd.cFileName)) {
            var ado = api.CreateObject("ads");
            ado.charset = 'utf-8';
            ado.Open();
            ado.LoadFromFile(fso.BuildPath(src, wfd.cFileName));
            var html = marked(ado.ReadText());
            ado.Close();
            alert(html);
            break;
		}
        bFind = api.FindNextFile(hFind, wfd);
	}
	api.FindClose(hFind);




}

